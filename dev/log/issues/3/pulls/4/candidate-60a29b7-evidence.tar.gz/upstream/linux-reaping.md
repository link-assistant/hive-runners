The bounded-run descendant test can fail on Linux after the grandchild has exited. Hive Runners uses the same test blob `5e86943f502b30b0480e8e938371bb5734969a74` as the template. The hosted Node run failed at the last `isAlive` assertion roughly 16 ms after the two-second timeout. That timing is consistent with the polling condition already observing an exit, followed by the final probe racing with reaping. [Hosted failure](https://github.com/link-assistant/hive-runners/actions/runs/45159625880/job/137647407938), [template test](https://github.com/link-foundation/js-ai-driven-development-pipeline-template/blob/8e72538d579d904aff818c2447fb3c2413d3a989/tests/bounded-run.test.js)

## Reproduce

Run this deterministic model with `node repro.mjs`. The initial probe succeeds while the child still has a PID. The process is reaped before the `/proc` read completes. The current fallback reports the process alive and the assertion fails.

```js
import assert from 'node:assert/strict';

let reaped = false;
function signalZero() {
  if (reaped) throw Object.assign(new Error('No such process'), { code: 'ESRCH' });
}
function readStat() {
  reaped = true;
  throw Object.assign(new Error('Process entry disappeared'), { code: 'ENOENT' });
}
function isAlive() {
  try {
    signalZero();
  } catch (error) {
    return error.code === 'EPERM';
  }
  try {
    return readStat().split(') ')[1][0] !== 'Z';
  } catch {
    return true;
  }
}
assert.equal(isAlive(), false);
```

On Linux, signal 0 tests PID existence and permission. A zombie can still have a PID. `/proc/<pid>/stat` reports the zombie process state as `Z`. [kill(2)](https://man7.org/linux/man-pages/man2/kill.2.html), [proc_pid_stat(5)](https://man7.org/linux/man-pages/man5/proc_pid_stat.5.html)

## Workaround and proposed change

Re-run the failed job when investigating a historical revision. For a durable change, read the Linux process state first and fall back to signal 0 when procfs cannot supply a result. Then assert the polling loop's last liveness observation so an observed exit is never followed by a second PID check. Keep the timeout, process group kill, and descendant assertions. Add the transition above as an injected regression test and run the bounded-run tests under Node, Bun, and Deno.
